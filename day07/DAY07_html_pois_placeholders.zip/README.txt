DAY07 csomag

1) Másold a day07 mappát a projekt gyökerébe a többi nap mellé.
   Példa: .../KekDuna/day07/

2) A főoldal (gyökér index.html) rácsába illeszd be a ROOT_INDEX_DAY07_SNIPPET.txt tartalmát.
   Ugyanoda tedd, ahol a DAY01..DAY06 blokkok vannak.

3) A képek placeholder fájlok.
   Cseréld le őket valódi fotókra, de a fájlnév maradjon pontosan ugyanaz.

Mappa tartalom
- day07/index.html
- day07/poi01.html ... poi16.html
- day07/images/*.jpg
